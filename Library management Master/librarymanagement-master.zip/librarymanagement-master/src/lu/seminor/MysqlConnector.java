package lu.seminor;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class MysqlConnector {

	public MysqlDataSource  getDataSource() {
		MysqlDataSource dataSource = new MysqlDataSource();
		dataSource.setUser("root");
		dataSource.setPassword("Satish@19");
		dataSource.setURL("jdbc:mysql://localhost:3306/library");
		return dataSource;
	}
}
